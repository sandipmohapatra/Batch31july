package in.nit.runner;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import in.nit.model.Product;
import in.nit.repo.ProductRepository;

@Component
public class ProductTestRunner implements CommandLineRunner{
	@Autowired
	private ProductRepository repo;
	
	@Override
	public void run(String... args) throws Exception {
		repo.save(new Product(10, "PEN", 50.25, "REN"));
		repo.save(new Product(26, "BOOK", 180.25, "REN"));
		repo.save(new Product(69, "NET", 590.25, "NIT"));
		repo.save(new Product(15, "GAME CD", 600.25, "NIT"));
		repo.save(new Product(20, "PEN", 150.25, "REN"));
		repo.save(new Product(21, "BOOK", 1180.25, "REN"));
		repo.save(new Product(22, "NET", 1590.25, "NIT"));
		repo.save(new Product(23, "GAME CD",1600.25, "NIT"));
	}
}
