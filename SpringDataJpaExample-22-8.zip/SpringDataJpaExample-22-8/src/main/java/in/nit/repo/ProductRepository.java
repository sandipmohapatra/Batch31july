package in.nit.repo;

import org.springframework.data.repository.PagingAndSortingRepository;

import in.nit.model.Product;

public interface ProductRepository 
	extends PagingAndSortingRepository<Product, Integer> {

}
