package tester;
import DAO.DaoDemo;
import DTO.DTODemo;
import java.util.*;
public class TestClass 
{
public static void main(String[] args) 
{
DTODemo obj=new DTODemo();
Scanner ob=new Scanner(System.in);
System.out.println("Enter id,name,address");
int id=ob.nextInt();
String name=ob.next();
String address=ob.next();
obj.setId(id);
obj.setName(name);
obj.setAddress(address);
System.out.println(obj);

DaoDemo obj1=new DaoDemo();
obj1.saveData(obj);
}
}
