package tester;
import DAO.DaoDemo;
import DTO.DTODemo;
public class TestClass 
{
public static void main(String[] args) 
{
DTODemo obj=new DTODemo();
obj.setId(102);
obj.setName("Shubham");
obj.setAddress("Bangalore");
System.out.println(obj);

DaoDemo obj1=new DaoDemo();
obj1.saveData(obj);
}
}
