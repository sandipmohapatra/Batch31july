package com.banking.bankingportal.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.banking.bankingportal.model.Contact_Query;

public interface ContactQueryRepo extends JpaRepository<Contact_Query,Integer>{

}
