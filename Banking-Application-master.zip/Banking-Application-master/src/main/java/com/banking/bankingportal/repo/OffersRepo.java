package com.banking.bankingportal.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.banking.bankingportal.model.Offers;

public interface OffersRepo extends JpaRepository<Offers,Integer>{

}
