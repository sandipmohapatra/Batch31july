package in.nit.model;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.NonNull;
import lombok.RequiredArgsConstructor;
@Entity
public class PanCard {
	@Id
	@NonNull
	
	private Integer panId;
	private String panCardNumber;
	private String panHolderName;
	@Temporal(TemporalType.DATE)
	private Date issuedDate;
	public PanCard() {
		super();
	}
	public PanCard(@NonNull Integer panId, String panCardNumber, String panHolderName, Date issuedDate) {
		super();
		this.panId = panId;
		this.panCardNumber = panCardNumber;
		this.panHolderName = panHolderName;
		this.issuedDate = issuedDate;
	}
	public Integer getPanId() {
		return panId;
	}
	public void setPanId(Integer panId) {
		this.panId = panId;
	}
	public String getPanCardNumber() {
		return panCardNumber;
	}
	public void setPanCardNumber(String panCardNumber) {
		this.panCardNumber = panCardNumber;
	}
	public String getPanHolderName() {
		return panHolderName;
	}
	public void setPanHolderName(String panHolderName) {
		this.panHolderName = panHolderName;
	}
	public Date getIssuedDate() {
		return issuedDate;
	}
	public void setIssuedDate(Date issuedDate) {
		this.issuedDate = issuedDate;
	}
	
}
