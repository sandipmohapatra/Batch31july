package in.nit.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import in.nit.model.PanCard;

public interface PanCardRepository extends JpaRepository<PanCard, Integer> {

	PanCard findByPanId(Integer panId);
	
}
