export class LoanList {
    customer_id: number;
    req_id: number;
    approve: boolean;
    loan_amt: number;
    loan_desc: string;
    loan_rate: number;
    loan_term: number;
    loan_type: string;
    req_dt: string;
}