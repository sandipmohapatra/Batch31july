export class LoanAccount {
    account_no: string;
}