export class TransactionDetails{
    transaction_id: number;
    account_num_sender: number;
    account_num_reciever: number;
    transaction_amt: number;
    transaction_dt: string;
    customer_id: number;
    trxnDescription: string;
    closing_bal_sender: number;
    closing_bal_reciever: number;

}