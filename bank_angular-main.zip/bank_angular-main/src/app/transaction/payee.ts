export class TrxnPayee {
    payee_account_no: number;
    name: string;
}