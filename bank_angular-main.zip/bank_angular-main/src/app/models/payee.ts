export class Payee{
    payee_id:number;
    name:string;
    payee_account_no:number;
    email:string;
    phone:string;
    bank_name:string;
}

