export class UserContactQuery {
  public query_id: number;
  public query_desc: string;
  public query_dt: string;
  public userName: string;
}
