export class CheckBook{
    req_id:number;
    account_no:number;
    no_of_leaf:string; 
    approve:boolean;
    req_dt:string;
    customer_id:number;
}