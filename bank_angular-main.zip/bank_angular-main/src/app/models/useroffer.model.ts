export class UserOffers {
  public offer_id: number;
  public offer_desc: string;
  public start_date: string;
  public expiry_date: string;
}
