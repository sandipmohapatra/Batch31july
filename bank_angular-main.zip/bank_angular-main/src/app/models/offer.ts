export class Offer{
    offer_id:number;
    offer_desc:string;
    start_date:string;
    expiry_date:string;
}