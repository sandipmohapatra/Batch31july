export class ContactQuery {
  public query_id: number;
  public query_desc: string;
  public name: string;
  public phone: string;
  public query_dt: string;
  public email: string;
}
