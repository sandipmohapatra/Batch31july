export class CreditCard{
    req_id:number;
    customer_id:number;
    pan_num:string;
    annual_salary:number;   
    type_of_card:string;
    approve:boolean;
    req_dt:string;
}
