import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-adminsidenav',
  templateUrl: './adminsidenav.component.html',
  styleUrls: ['./adminsidenav.component.css'],
})
export class AdminsidenavComponent implements OnInit {
  constructor() {}

  ngOnInit(): void {}
}
