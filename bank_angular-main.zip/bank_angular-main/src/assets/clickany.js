$(document).click(function(e) { 
    // Check for left button
    if (e.button == 0) {
        alert('clicked'); 
    }
});