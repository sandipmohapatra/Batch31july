package com.example.demo;

import java.util.Arrays;
import java.util.Optional;
import java.util.Scanner;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;
@Component
public class TestMongodb implements CommandLineRunner
{
@Autowired
private EmployeeRepository repo;
	@Override
	public void run(String... args) throws Exception {
	Employee emp=new Employee();
	Scanner ob=new Scanner(System.in);
	System.out.println("enter id,empid,name,salary");
		String id=ob.next();
		int eid=ob.nextInt();
		String name=ob.next();
		Double sal=ob.nextDouble();
		
		emp.setId(id);emp.setEid(eid);emp.setEname(name);emp.setEsal(sal);
		repo.save(emp);
		repo.deleteAll();
		Employee emp1=new Employee(id,eid,name,sal);
		repo.save(emp1);
		Employee emp2=new Employee("aabbccdd1122aa",4,"Madhu",56000.25);
		repo.save(emp2);
		Employee emp3=new Employee("aabbccdd32122aa",5,"Trupti",66000.25);
		repo.save(emp3);
		repo.save(new Employee("aaqqecdd32122aa",9,"Shubham",86000.25));
		repo.saveAll(
				Arrays.asList(
						new Employee("aabwecdd32122aa",6,"Afreen",66000.25),
						new Employee("aabweddd32122aa",7,"Geeta",76000.25),
						new Employee("aabwecdd32122aa",8,"Deepak",86000.25)
						)
								);
	//print all the records
		repo.findAll().forEach(System.out::println);
		
		repo.deleteById("aabwecdd32122aa");
		
		Optional<Employee> opt=repo.findById("aabweddd32122aa");
		if(opt.isEmpty())
		{
			System.out.println("No Data Found");
		}
		else
		{
			System.out.println("This is the data"+opt.get());
		}
	}
	}
