package com.example.demo;

import java.util.List;

public interface IEmployeeService 
{
public Integer saveEmployee(Employee c);
public List<Employee> getAllEmployee();
public Employee getOneEmployee(Integer id);
}
