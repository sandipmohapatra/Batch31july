package com.example.demo;

import java.util.List;

public interface IProductService 
{
public Integer saveProduct(Product c);
public List<Product> getAllProduct();
public Product getOneProduct(Integer id);
}
