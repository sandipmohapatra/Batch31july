package com.example.demo;

import java.util.*;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class StudentServiceImpl implements IStudentService 
{
@Autowired
private StudentRepository repo;
Student x=null;

	@Override
	public Integer saveStudent(Student c) {
		c=repo.save(c);
		return c.getSid();
	}

	@Override
	public List<Student> getAllStudent() {
		List x=(List) repo.findAll();
		return x;
	}

	@Override
	public Student getOneStudent(Integer id) {
	Optional<Student> opt=repo.findById(id);
		return opt.get();
	}

}
