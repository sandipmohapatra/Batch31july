package com.example.demo;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

@Entity
public class Student 
{
@Id
@GeneratedValue
private Integer sid;
private String sname;
private String grade;
public Integer getSid() {
	return sid;
}
public void setSid(Integer sid) {
	this.sid = sid;
}
public String getSname() {
	return sname;
}
public void setSname(String sname) {
	this.sname = sname;
}
public String getGrade() {
	return grade;
}
public void setGrade(String grade) {
	this.grade = grade;
}
public Student(Integer sid, String sname, String grade) {
	super();
	this.sid = sid;
	this.sname = sname;
	this.grade = grade;
}
public Student() {
	super();
}
@Override
public String toString() {
	return "Student [sid=" + sid + ", sname=" + sname + ", grade=" + grade + "]";
}

}